
local tiantang=GameMain:GetMod("开启功法1610315965浩然");
function tiantang:OnInit()
CS.XiaWorld.NpcLuaHelper(CS.XiaWorld.Npc()):UnLockGong("功法1610315965浩然")
end
