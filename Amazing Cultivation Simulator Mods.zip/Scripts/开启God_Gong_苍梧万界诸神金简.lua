
local tiantang=GameMain:GetMod("开启God_Gong_苍梧万界诸神金简");
function tiantang:OnInit()
CS.XiaWorld.NpcLuaHelper(CS.XiaWorld.Npc()):UnLockGong("God_Gong_苍梧万界诸神金简")
end