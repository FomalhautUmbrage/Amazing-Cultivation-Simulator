
local tiantang=GameMain:GetMod("开启功法1607374719测试法");
function tiantang:OnInit()
CS.XiaWorld.NpcLuaHelper(CS.XiaWorld.Npc()):UnLockGong("功法1607374719测试法")
end
