
local tiantang=GameMain:GetMod("开启功法1607298978点苍残卷");
function tiantang:OnInit()
CS.XiaWorld.NpcLuaHelper(CS.XiaWorld.Npc()):UnLockGong("功法1607298978点苍残卷")
end
